export interface PaymentChannel {
  id: string;
  name: string;
  shortName: string;
  category: 'Kantor Pos & Ekspedisi' | 'Minimarket & Retail' | 'Bank Transfer & ATM' | 'PPOB & FinTech' | 'E-Commerce';
  brandColor: string;
  bgLight: string;
  borderLight: string;
  logoType: 'pos_indonesia' | 'alfamart' | 'indomaret' | 'bca' | 'mandiri' | 'ottopay' | 'fastpay' | 'shopee' | 'tokopedia';
  instructions: string[];
  keterangan: string;
}

export const AETRA_PAYMENT_CHANNELS: PaymentChannel[] = [
  {
    id: 'pos_indonesia',
    name: 'PT Pos Indonesia / Pospay',
    shortName: 'Pos Indonesia',
    category: 'Kantor Pos & Ekspedisi',
    brandColor: '#F37021',
    bgLight: 'bg-orange-50',
    borderLight: 'border-orange-200',
    logoType: 'pos_indonesia',
    keterangan: 'Loket Kantor Pos seluruh Indonesia & Aplikasi Pospay Mobile',
    instructions: [
      'Datangi loket Kantor Pos terdekat atau buka aplikasi Pospay.',
      'Sampaikan kepada petugas kasir untuk pembayaran tagihan/pemasangan air PT Aetra Air Tangerang.',
      'Tunjukkan atau sebutkan Nomor Formulir / Nomor Sambungan (No. Form / No. SR).',
      'Petugas akan memverifikasi nama pemohon dan total biaya.',
      'Lakukan pembayaran tunai atau saldo Pospay, simpan resi cetak sebagai bukti bayar sah.',
    ],
  },
  {
    id: 'alfamart',
    name: 'Alfamart / Alfamidi / Dan+Dan',
    shortName: 'Alfamart',
    category: 'Minimarket & Retail',
    brandColor: '#E11B22',
    bgLight: 'bg-red-50',
    borderLight: 'border-red-200',
    logoType: 'alfamart',
    keterangan: 'Gerai Alfamart, Alfamidi, Alfa Express, & Dan+Dan terdekat',
    instructions: [
      'Kunjungi kasir gerai Alfamart atau Alfamidi terdekat.',
      'Sampaikan bahwa Anda ingin melakukan pembayaran tagihan air PDAM / Aetra Air Tangerang.',
      'Berikan Nomor Formulir (No. Form) atau Nomor Sambungan (No. SR) Anda.',
      'Kasir akan membacakan rincian nama pemilik dan jumlah biaya sambungan baru.',
      'Bayar sesuai nominal yang tertera di layar kasir dan minta struk pembayaran resmi.',
    ],
  },
  {
    id: 'indomaret',
    name: 'Indomaret / Indomaret Point',
    shortName: 'Indomaret',
    category: 'Minimarket & Retail',
    brandColor: '#005DAA',
    bgLight: 'bg-blue-50',
    borderLight: 'border-blue-200',
    logoType: 'indomaret',
    keterangan: 'Gerai Indomaret di seluruh wilayah Tangerang & sekitarnya',
    instructions: [
      'Datangi kasir Indomaret atau melalui mesin i.Saku / Klik Indomaret.',
      'Pilih atau infokan pembayaran PDAM / Air Bersih -> Aetra Air Tangerang.',
      'Sebutkan No. Form pendaftaran atau No. SR Anda.',
      'Pastikan nama pemohon dan nominal tagihan sesuai sebelum membayar.',
      'Selesaikan transaksi dengan uang tunai, debit, atau QRIS dan simpan struk kasir.',
    ],
  },
  {
    id: 'bca',
    name: 'Bank Central Asia (BCA)',
    shortName: 'Bank BCA',
    category: 'Bank Transfer & ATM',
    brandColor: '#005DAA',
    bgLight: 'bg-blue-50',
    borderLight: 'border-blue-200',
    logoType: 'bca',
    keterangan: 'ATM BCA, myBCA, BCA mobile (m-BCA), & KlikBCA',
    instructions: [
      'Buka aplikasi BCA mobile / myBCA atau kunjungi ATM BCA.',
      'Pilih menu "m-Payment" / "Pembayaran" -> "Air / PAM" atau "Publik / Utilitas".',
      'Pilih Perusahaan Air: "AETRA AIR TANGERANG" (Kode PDAM / Aetra).',
      'Masukkan Nomor Formulir / Nomor Sambungan (No. Form / No. SR).',
      'Konfirmasi detail tagihan & nama pelanggan yang tampil di layar, lalu masukkan PIN transaksi.',
    ],
  },
  {
    id: 'mandiri',
    name: 'Bank Mandiri / Livin\' by Mandiri',
    shortName: 'Bank Mandiri',
    category: 'Bank Transfer & ATM',
    brandColor: '#003366',
    bgLight: 'bg-amber-50',
    borderLight: 'border-amber-200',
    logoType: 'mandiri',
    keterangan: 'Livin\' by Mandiri, ATM Mandiri, & Mandiri Internet Banking',
    instructions: [
      'Buka aplikasi Livin\' by Mandiri atau mesin ATM Mandiri.',
      'Pilih menu "Bayar" -> "PAM / Air Minum".',
      'Cari penyedia jasa: "Aetra Air Tangerang" (Kode Biller: Aetra Tangerang).',
      'Ketikkan Nomor Registrasi Form atau Nomor Pelanggan Anda.',
      'Periksa nominal tagihan yang tertera, klik Lanjut dan masukkan PIN Livin\' Mandiri.',
    ],
  },
  {
    id: 'ottopay',
    name: 'OttoPay',
    shortName: 'OttoPay',
    category: 'PPOB & FinTech',
    brandColor: '#0070BA',
    bgLight: 'bg-sky-50',
    borderLight: 'border-sky-200',
    logoType: 'ottopay',
    keterangan: 'Mitra Agen Warung OttoPay & Aplikasi OttoPay',
    instructions: [
      'Kunjungi gerai mitra warung berlogo OttoPay terdekat atau buka aplikasi OttoPay.',
      'Pilih menu "Tagihan Air / PDAM" -> pilih "Aetra Air Tangerang".',
      'Masukkan ID Pelanggan / Nomor Formulir Aetra.',
      'Cek kebenaran data pelanggan dan jumlah pembayaran.',
      'Lakukan pembayaran dan terima bukti transaksi digital/struk cetak dari mitra OttoPay.',
    ],
  },
  {
    id: 'fastpay',
    name: 'Toko Modern Fastpay',
    shortName: 'Fastpay',
    category: 'PPOB & FinTech',
    brandColor: '#005BAC',
    bgLight: 'bg-indigo-50',
    borderLight: 'border-indigo-200',
    logoType: 'fastpay',
    keterangan: 'Jaringan Loket Toko Modern Fastpay & Aplikasi Fastpay',
    instructions: [
      'Datangi loket mitra Toko Modern Fastpay di lingkungan Anda.',
      'Sampaikan ingin membayar sambungan baru / tagihan PT Aetra Air Tangerang.',
      'Berikan Nomor Form / Nomor SR kepada agen Fastpay.',
      'Agen akan memproses cek tagihan langsung ke server resmi Aetra.',
      'Bayar sesuai jumlah yang ditagihkan dan simpan bukti struk Fastpay bertanda lunas.',
    ],
  },
  {
    id: 'shopee',
    name: 'Shopee / ShopeePay',
    shortName: 'Shopee',
    category: 'E-Commerce',
    brandColor: '#EE4D2D',
    bgLight: 'bg-orange-50',
    borderLight: 'border-orange-200',
    logoType: 'shopee',
    keterangan: 'Aplikasi Shopee (Menu Pulsa, Tagihan & Tiket -> PDAM)',
    instructions: [
      'Buka aplikasi Shopee di ponsel Anda.',
      'Pilih menu "Pulsa, Tagihan & Tiket" -> pilih kategori "PDAM / Air Bersih".',
      'Pilih Wilayah: "Kab. Tangerang" / "Aetra Air Tangerang".',
      'Masukkan Nomor Formulir atau Nomor Sambungan Anda.',
      'Klik "Lihat Tagihan", gunakan ShopeePay / Transfer Bank / Mitra Agen, lalu selesaikan pembayaran.',
    ],
  },
  {
    id: 'tokopedia',
    name: 'Tokopedia',
    shortName: 'Tokopedia',
    category: 'E-Commerce',
    brandColor: '#03AC0E',
    bgLight: 'bg-emerald-50',
    borderLight: 'border-emerald-200',
    logoType: 'tokopedia',
    keterangan: 'Aplikasi & Website Tokopedia (Menu Top-Up & Tagihan -> Air PDAM)',
    instructions: [
      'Buka aplikasi atau website Tokopedia.',
      'Masuk ke menu "Top-Up & Tagihan" -> klik "Air PDAM".',
      'Pilih Wilayah Operator: "Aetra Air Tangerang" atau "Kabupaten Tangerang (Aetra)".',
      'Masukkan Nomor Pelanggan / Nomor Form.',
      'Klik "Cek Tagihan", periksa rincian biaya, dan pilih metode pembayaran favorit Anda (GoPay, Virtual Account, dsb).',
    ],
  },
];

export const OFFICIAL_PAYMENT_CHANNELS = AETRA_PAYMENT_CHANNELS;

