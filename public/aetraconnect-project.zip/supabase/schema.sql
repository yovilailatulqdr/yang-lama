-- ==============================================================================
-- SKEMA DATABASE SUPABASE - PT AETRA AIR TANGERANG
-- Jalankan skrip SQL ini di menu: "SQL Editor" -> "New Query" di Supabase Dashboard Anda.
-- ==============================================================================

-- 1. TABEL AKUN PENGGUNA (Admin & Pelanggan)
CREATE TABLE IF NOT EXISTS public.user_accounts (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  nama TEXT NOT NULL,
  id_pelanggan TEXT,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW())
);

-- 2. TABEL PENDAFTARAN SAMBUNGAN BARU (Registrations)
CREATE TABLE IF NOT EXISTS public.registrations (
  id TEXT PRIMARY KEY,
  no_form TEXT UNIQUE NOT NULL,
  no_sr TEXT,
  id_pelanggan TEXT,
  tanggal DATE DEFAULT CURRENT_DATE,
  nama_ktp TEXT NOT NULL,
  no_ktp TEXT NOT NULL,
  email TEXT,
  telp_hp TEXT,
  alamat_ktp TEXT NOT NULL,
  rt_rw_ktp TEXT,
  kecamatan_ktp TEXT,
  desa_ktp TEXT,
  kode_pos_ktp TEXT,
  kelurahan_ktp TEXT,
  alamat_pasang TEXT NOT NULL,
  rt_rw_pasang TEXT,
  kecamatan_pasang TEXT,
  desa_pasang TEXT,
  kode_pos_pasang TEXT,
  kelurahan_pasang TEXT,
  pekerjaan TEXT,
  status_kepemilikan TEXT,
  status_kepemilikan_lainnya TEXT,
  luas_tanah TEXT,
  luas_bangunan TEXT,
  total_luas_bangunan NUMERIC,
  fungsi_bangunan TEXT,
  golongan_tarif TEXT,
  kategori_tarif_klausul TEXT,
  skema_pembayaran TEXT DEFAULT 'Bayar Lunas',
  keterangan_skema TEXT,
  biaya_sambungan NUMERIC DEFAULT 1371545,
  kondisi_bangunan JSONB DEFAULT '{}'::jsonb,
  lingkungan JSONB DEFAULT '{}'::jsonb,
  persyaratan JSONB DEFAULT '{}'::jsonb,
  persyaratan_files JSONB DEFAULT '{}'::jsonb,
  data_pasang JSONB DEFAULT '{}'::jsonb,
  foto_properti_files JSONB DEFAULT '[]'::jsonb,
  persetujuan BOOLEAN DEFAULT true,
  tracking_step INTEGER DEFAULT 1,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW())
);

-- 3. TABEL PELACAKAN SAMBUNGAN (Tracking Records)
CREATE TABLE IF NOT EXISTS public.tracking_records (
  no_form TEXT PRIMARY KEY,
  no_sr TEXT,
  id_pelanggan TEXT,
  email TEXT,
  nama TEXT NOT NULL,
  telp TEXT,
  alamat TEXT,
  current_step INTEGER DEFAULT 1,
  tanggal_daftar TEXT,
  estimasi_selesai TEXT DEFAULT '14 Hari Kerja (Estimasi Air Mengalir)',
  golongan_tarif TEXT,
  biaya_sambungan NUMERIC DEFAULT 1371545,
  status_pembayaran TEXT DEFAULT 'Menunggu Pembayaran',
  nomor_meter TEXT,
  nomor_segel TEXT,
  admin_notes TEXT,
  last_updated_by_admin TEXT,
  petugas_surveyor JSONB DEFAULT '{}'::jsonb,
  petugas_teknisi JSONB DEFAULT '{}'::jsonb,
  steps JSONB DEFAULT '[]'::jsonb,
  timeline_events JSONB DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW())
);

-- 4. TABEL SURVEY KEPUASAN PELANGGAN (18 Pertanyaan)
CREATE TABLE IF NOT EXISTS public.surveys (
  id TEXT PRIMARY KEY,
  nama TEXT NOT NULL,
  no_pelanggan_or_sr TEXT,
  kecamatan TEXT,
  desa TEXT,
  kelurahan TEXT,
  -- 18 Pertanyaan Bintang 1-5
  q1_kualitas_syarat INTEGER,
  q2_kualitas_warna INTEGER,
  q3_kualitas_bau INTEGER,
  q4_kuantitas_24jam INTEGER,
  q5_kuantitas_volume INTEGER,
  q6_kontinuitas_tekanan INTEGER,
  q7_kontinuitas_penurunan INTEGER,
  q8_teknis_kecepatan INTEGER,
  q9_teknis_sikap INTEGER,
  q10_keluhan_ramah INTEGER,
  q11_keluhan_cepat INTEGER,
  q12_keluhan_komunikasi INTEGER,
  q13_meter_ramah INTEGER,
  q14_meter_tanggap INTEGER,
  q15_meter_akurat INTEGER,
  q16_tagihan_alamat INTEGER,
  q17_tagihan_m3 INTEGER,
  q18_tagihan_pilihan INTEGER,
  -- Indikator rata-rata
  kualitas_air NUMERIC,
  kontinuitas_aliran NUMERIC,
  kecepatan_pelayanan NUMERIC,
  kemudahan_tagihan NUMERIC,
  profesionalisme_petugas NUMERIC,
  csat_overall NUMERIC,
  nps_score NUMERIC,
  komentar TEXT,
  kategori_masukan TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW())
);

-- 5. TABEL TAGIHAN BULANAN (Monthly Bills)
CREATE TABLE IF NOT EXISTS public.monthly_bills (
  id TEXT PRIMARY KEY,
  id_pelanggan TEXT NOT NULL,
  no_sr TEXT,
  nama TEXT NOT NULL,
  alamat TEXT,
  golongan_tarif TEXT,
  nomor_meter TEXT,
  periode_bulan TEXT NOT NULL,
  tanggal_jatuh_tempo TEXT,
  stand_lalu NUMERIC DEFAULT 0,
  stand_kini NUMERIC DEFAULT 0,
  pemakaian_m3 NUMERIC DEFAULT 0,
  rincian_blok JSONB DEFAULT '{}'::jsonb,
  biaya_air NUMERIC DEFAULT 0,
  biaya_pemeliharaan_meter NUMERIC DEFAULT 0,
  biaya_administrasi NUMERIC DEFAULT 0,
  retribusi NUMERIC DEFAULT 0,
  denda NUMERIC DEFAULT 0,
  biaya_pembukaan_segel NUMERIC DEFAULT 0,
  biaya_lainnya NUMERIC DEFAULT 0,
  total_tagihan NUMERIC DEFAULT 0,
  status TEXT DEFAULT 'BELUM LUNAS',
  tanggal_bayar TEXT,
  metode_bayar TEXT,
  no_referensi TEXT,
  bukti_bayar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc'::text, NOW())
);

-- ==============================================================================
-- KEBIJAKAN KEAMANAN ROW LEVEL SECURITY (RLS)
-- Mengizinkan aplikasi frontend SPA (Vercel) untuk membaca & menulis data dengan Anon Key
-- ==============================================================================

ALTER TABLE public.user_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tracking_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.surveys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_bills ENABLE ROW LEVEL SECURITY;

-- Buat Policy Akses Publik untuk Anon Key (Full CRUD untuk demo & operasional web)
DROP POLICY IF EXISTS "Public access user_accounts" ON public.user_accounts;
CREATE POLICY "Public access user_accounts" ON public.user_accounts FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access registrations" ON public.registrations;
CREATE POLICY "Public access registrations" ON public.registrations FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access tracking_records" ON public.tracking_records;
CREATE POLICY "Public access tracking_records" ON public.tracking_records FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access surveys" ON public.surveys;
CREATE POLICY "Public access surveys" ON public.surveys FOR ALL USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "Public access monthly_bills" ON public.monthly_bills;
CREATE POLICY "Public access monthly_bills" ON public.monthly_bills FOR ALL USING (true) WITH CHECK (true);

-- ==============================================================================
-- DATA AWAL (SEED DATA DEFAULT)
-- ==============================================================================

-- Akun Administrator default
INSERT INTO public.user_accounts (id, email, nama, id_pelanggan, password, role)
VALUES 
  ('acc-admin', 'admin@aetra.co.id', 'Administrator Aetra Tangerang', '10999999', 'aetra123', 'admin'),
  ('acc-cust-1', 'bambang.supriyanto@gmail.com', 'Bambang Supriyanto', '10842918', 'password123', 'customer')
ON CONFLICT (id) DO NOTHING;

-- Berikan hak akses pada role anon dan authenticated
GRANT ALL ON TABLE public.user_accounts TO anon, authenticated;
GRANT ALL ON TABLE public.registrations TO anon, authenticated;
GRANT ALL ON TABLE public.tracking_records TO anon, authenticated;
GRANT ALL ON TABLE public.surveys TO anon, authenticated;
GRANT ALL ON TABLE public.monthly_bills TO anon, authenticated;
